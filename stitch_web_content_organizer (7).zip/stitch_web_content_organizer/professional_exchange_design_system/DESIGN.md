---
name: Professional Exchange Design System
colors:
  surface: '#faf8ff'
  surface-dim: '#dad9df'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f9'
  surface-container: '#eeedf3'
  surface-container-high: '#e9e7ed'
  surface-container-highest: '#e3e2e8'
  on-surface: '#1a1b20'
  on-surface-variant: '#444650'
  inverse-surface: '#2f3035'
  inverse-on-surface: '#f1f0f6'
  outline: '#747781'
  outline-variant: '#c4c6d2'
  surface-tint: '#415c9d'
  primary: '#001a48'
  on-primary: '#ffffff'
  primary-container: '#0a2e6d'
  on-primary-container: '#7d98dd'
  inverse-primary: '#b1c5ff'
  secondary: '#006e2d'
  on-secondary: '#ffffff'
  secondary-container: '#7cf994'
  on-secondary-container: '#007230'
  tertiary: '#131f1a'
  on-tertiary: '#ffffff'
  tertiary-container: '#28342e'
  on-tertiary-container: '#8f9d95'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b1c5ff'
  on-primary-fixed: '#001946'
  on-primary-fixed-variant: '#274484'
  secondary-fixed: '#7ffc97'
  secondary-fixed-dim: '#62df7d'
  on-secondary-fixed: '#002109'
  on-secondary-fixed-variant: '#005320'
  tertiary-fixed: '#d8e6dd'
  tertiary-fixed-dim: '#bccac1'
  on-tertiary-fixed: '#121e19'
  on-tertiary-fixed-variant: '#3d4a43'
  background: '#faf8ff'
  on-background: '#1a1b20'
  surface-variant: '#e3e2e8'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system is engineered for a professional networking and exchange platform, prioritizing trust, clarity, and institutional reliability. The aesthetic follows a **Corporate Modern** approach, blending high-utility layouts with a soft, approachable finish. 

The target audience consists of professionals and stakeholders who require a stable and efficient environment for matching and verification. The UI evokes a sense of "secure growth"—using a structured grid and a sophisticated palette to signal competence, while incorporating rounded forms to remain accessible. Visual clutter is minimized to keep the focus on data accuracy and user connectivity.

## Colors
This design system utilizes a hierarchical color strategy to differentiate between navigation and action. **Deep Navy Blue** provides the structural anchor, used for global navigation, footers, and authoritative headings. **Professional Green** is reserved for primary actions, indicating progress and successful outcomes.

Background surfaces use subtle tints—**Soft Blue** for information-dense areas like dashboards and heroes, and **Light Green** for specific success-oriented callouts. The status and match score palettes follow a standard traffic-light logic to ensure instant cognitive recognition of data quality and urgency.

## Typography
**Manrope** is used throughout the design system to maintain a modern, balanced, and highly legible interface. The scale relies on tight line-heights for headlines to create a compact, professional feel, while body text is given generous leading (1.5x) to ensure readability during long sessions of data review.

- **Headlines:** Use Bold (700) or ExtraBold (800) for primary titles to establish a strong hierarchy against the Navy Blue.
- **Labels:** Use SemiBold (600) for interactive elements like buttons and navigation items to ensure they stand out from static body text.
- **Mobile Scaling:** Headline sizes drop by approximately 25% on mobile to maintain vertical rhythm without overwhelming the viewport.

## Layout & Spacing
The system employs a **12-column fixed grid** for desktop (max-width 1280px) and a **4-column fluid grid** for mobile. The spacing rhythm is based on a **4px baseline**, with 16px (md) and 24px (lg) being the primary increments for internal component padding and section margins respectively.

- **Gutters:** 24px across tablet and desktop to provide clear visual separation between cards and content blocks.
- **Dashboard Widgets:** Should utilize a consistent 16px or 24px internal padding (depending on complexity) to maintain alignment across the grid.

## Elevation & Depth
This design system uses **Tonal Layers** combined with **Low-contrast outlines** to create depth without relying on heavy shadows. 

- **Level 0 (Base):** White (#FFFFFF) or Soft Backgrounds (#F5F9FF / #EAF8EF).
- **Level 1 (Cards/Widgets):** White background with a 1px border (#E5E7EB).
- **Level 2 (Hover/Active):** A very soft, diffused shadow (0px 4px 12px, 5% opacity) is applied to cards upon interaction to indicate clickability.
- **Navigation:** The Top Bar uses a solid Deep Navy Blue (#0A2E6D) fill, creating a hard "header" layer that anchors the rest of the fluid content.

## Shapes
Following the requirement for **rounded-eight corners**, the standard border-radius for all primary UI components (Buttons, Input Fields, Cards) is **0.5rem (8px)**. 

- **Small elements:** (Tags, Chips) use the base 4px or 8px radius.
- **Large containers:** (Modals, Feature Sections) may scale up to 16px (1rem) for a softer, more modern "nested" appearance.
- **Map Markers:** Circular or pill-shaped to contrast against the geometric province boundaries.

## Components
- **Buttons:** Primary buttons use Professional Green (#16A34A) with White text. Secondary/Ghost buttons use Deep Navy Blue (#0A2E6D) text with a thin border. All buttons use 8px rounded corners and SemiBold typography.
- **Chips & Badges:** Verified badges feature a Green (#22C55E) checkmark. Match percentage chips use a background color corresponding to the Match Score palette with high-contrast text.
- **Input Fields:** 1px border (#E5E7EB), 8px radius. Focus state uses a 2px Deep Navy Blue stroke.
- **Cards:** White background, 1px light gray border, 8px radius. Use "Soft Blue" (#F5F9FF) for internal widget headers within a card.
- **Maps:** Provincial map views use the designated Zambia Map Theme. Province labels are always Deep Navy Blue for legibility. Markers are Professional Green with white numerals for clear visibility.
- **Lists:** Clean, border-bottom separated rows. Actionable items use a subtle gray hover state.