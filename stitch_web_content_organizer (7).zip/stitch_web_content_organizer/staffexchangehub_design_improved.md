---
name: StaffExchangeHub Design System
version: 1.1
status: Improved from Listing Page UI
brand: StaffExchangeHub
website: staffexchangehub.com
---

# StaffExchangeHub Design System

## 1. Brand Direction

StaffExchangeHub is a professional workplace exchange platform for people who want to swap work locations, institutions, districts, or provinces.

The design must communicate trust, professionalism, career mobility, safety, simplicity, and institutional reliability.

The platform should not look like a casual social media site. It should feel closer to a professional marketplace, employment platform, or verified directory.

---

## 2. Core Design Principle

Every page must help users complete one of four actions:

1. Find a swap
2. Evaluate a match
3. Contact a professional
4. Complete a workplace exchange

Decorative content should never compete with these actions.

---

## 3. Color System

### Primary Green

Used for primary actions, verification, success states, match confidence, and active navigation.

```css
--primary: #005f2e;
--primary-container: #007a3d;
--on-primary: #ffffff;
```

### Midnight Navy

Used for headings, footer, navigation emphasis, and professional authority.

```css
--secondary: #3a5f94;
--on-secondary: #ffffff;
```

### Surface Colors

```css
--background: #f9f9fc;
--surface: #f9f9fc;
--surface-container-lowest: #ffffff;
--surface-container-low: #f3f3f6;
--surface-container: #eeeef0;
--surface-container-high: #e8e8ea;
--surface-container-highest: #e2e2e5;
```

### Text Colors

```css
--on-background: #1a1c1e;
--on-surface: #1a1c1e;
--on-surface-variant: #3f493f;
--outline: #6f7a6f;
--outline-variant: #becabc;
```

### Functional Colors

```css
--success: #16a34a;
--warning: #f59e0b;
--error: #ba1a1a;
--error-container: #ffdad6;
--info-blue: #1f477b;
```

### Premium Gold

Use this only for premium memberships, featured listings, paid visibility, or sponsored areas.

```css
--premium-gold: #d4a017;
```

---

## 4. Typography

### Headings

Use **Manrope** for all major headings.

```css
--display-lg-font: Manrope;
--display-lg-size: 48px;
--display-lg-weight: 700;
--display-lg-line-height: 1.2;

--headline-lg-font: Manrope;
--headline-lg-size: 32px;
--headline-lg-weight: 700;
--headline-lg-line-height: 1.3;

--headline-md-font: Manrope;
--headline-md-size: 24px;
--headline-md-weight: 600;
--headline-md-line-height: 1.4;

--headline-sm-font: Manrope;
--headline-sm-size: 20px;
--headline-sm-weight: 600;
--headline-sm-line-height: 1.4;
```

### Body Text

Use **Inter** for body copy, forms, listing details, filters, labels, and dashboard data.

```css
--body-lg-font: Inter;
--body-lg-size: 16px;
--body-lg-weight: 400;
--body-lg-line-height: 1.6;

--body-md-font: Inter;
--body-md-size: 14px;
--body-md-weight: 400;
--body-md-line-height: 1.5;

--body-sm-font: Inter;
--body-sm-size: 13px;
--body-sm-weight: 400;
--body-sm-line-height: 1.5;

--label-lg-font: Inter;
--label-lg-size: 14px;
--label-lg-weight: 600;

--label-md-font: Inter;
--label-md-size: 12px;
--label-md-weight: 500;
```

---

## 5. Layout System

### Desktop Container

```css
--container-max: 1200px;
--grid-columns: 12;
--gutter: 24px;
```

### Spacing

```css
--spacing-base: 4px;
--spacing-xs: 8px;
--spacing-sm: 16px;
--spacing-md: 24px;
--spacing-lg: 32px;
--spacing-xl: 48px;
```

### Dashboard Sidebar

```css
--sidebar-width: 260px;
```

Use a fixed left sidebar for dashboard pages and member account pages.

---

## 6. Rounded Corners

```css
--radius-sm: 0.25rem;
--radius-default: 0.5rem;
--radius-md: 0.75rem;
--radius-lg: 1rem;
--radius-xl: 1.5rem;
--radius-full: 9999px;
```

Recommended use:

- Buttons: 8px
- Inputs: 8px
- Listing cards: 16px
- Dashboard cards: 16px
- Profile avatars: full circle
- Notification badges: full circle

---

## 7. Elevation and Borders

The platform should rely on clean borders and tonal layers instead of heavy shadows.

### Standard Card

```css
background: #ffffff;
border: 1px solid #e2e8f0;
border-radius: 16px;
box-shadow: 0px 4px 12px rgba(0,0,0,0.05);
```

### Hover State

```css
border-color: #005f2e;
box-shadow: 0px 6px 16px rgba(0,0,0,0.08);
```

Use hover effects only for interactive cards.

---

## 8. Buttons

### Primary Button

Use for the most important action on the page.

Examples:

- Create Swap Post
- Search Swaps
- Send Interest
- Choose Premium

```css
background: #005f2e;
color: #ffffff;
border-radius: 8px;
font-weight: 600;
```

### Secondary Button

Use for supportive actions.

Examples:

- View Profile
- Save Search
- Browse Swaps

```css
background: #ffffff;
color: #005f2e;
border: 1px solid #005f2e;
border-radius: 8px;
```

### Ghost Button

Use for low priority or safety actions.

Examples:

- Report Post
- Report Profile
- Not Interested

```css
background: transparent;
border: none;
color: #ba1a1a;
```

---

## 9. Listing Page Design

The Listing Page is one of the most important pages on StaffExchangeHub. It must help users compare swap opportunities quickly.

### Page Structure

Desktop layout:

```text
Header
Left Filter Sidebar | Main Listings Area
Footer
```

Left sidebar width:

```css
width: 300px;
```

Main content:

```css
flex: 1;
```

---

## 10. Filter Sidebar Component

The filter sidebar must stay clean, structured, and easy to scan.

### Sidebar Sections

1. Current Location
2. Desired Location
3. Profession
4. Employer Type
5. Experience Level
6. More Filters
7. Apply Filters
8. Save Search
9. Advertisement Area

### More Filters

Use checkboxes for:

- Verified Users Only
- Housing Available
- Urgent Swaps Only
- Gender Preference

### Sidebar Style

```css
background: #ffffff;
border: 1px solid #e2e8f0;
border-radius: 16px;
padding: 16px;
```

On mobile, the filter sidebar should become a slide-over drawer.

---

## 11. Listing Card Component

The listing card is the core marketplace component.

### Card Structure

```text
Profile Info | Current Workplace | Swap Icon | Desired Workplace | Match Score | Actions
```

### Required Fields

Each listing card should show:

- Profile photo
- Name
- Verified badge
- Profession
- Years of experience
- Posted date
- Current workplace
- Current district and province
- Desired workplace
- Desired district and province
- Employer type chip
- Housing chip
- Urgency chip
- Match percentage
- View Profile button
- Save icon
- Report Post link

### Listing Card Style

```css
background: #ffffff;
border: 1px solid #e2e8f0;
border-radius: 16px;
padding: 20px;
min-height: 140px;
```

### Desktop Card Layout

```text
[Avatar + User Details] [Current Workplace] [Swap Icon] [Desired Workplace] [Match Score] [Actions]
```

### Mobile Card Layout

```text
Profile Info
Current Workplace
Desired Workplace
Status Chips
Match Score
Actions
```

---

## 12. Match Score System

Match score should always appear on the far-right side of listing cards on desktop.

### 95% to 100%

Label:

```text
Excellent Match
```

Color:

```css
#16a34a
```

### 85% to 94%

Label:

```text
Good Match
```

Color:

```css
#65a30d
```

### 70% to 84%

Label:

```text
Moderate Match
```

Color:

```css
#f59e0b
```

### Below 70%

Label:

```text
Low Match
```

Color:

```css
#ef4444
```

### Match Score Card

```css
background: #eaf8ef;
color: #005f2e;
border-radius: 12px;
font-weight: 700;
```

---

## 13. Status Chips

Status chips help users scan information quickly.

### Verification Chip

```css
background: #eaf8ef;
color: #005f2e;
```

Label examples:

- Verified
- Verified Member
- Employer Verified

### Institution Type Chip

```css
background: #e8f1ff;
color: #1f477b;
```

Label examples:

- Government Hospital
- Government School
- Banking
- NGO
- Private Sector

### Housing Chip

```css
background: #eaf8ef;
color: #005f2e;
```

Label examples:

- Housing Available
- Housing Not Included

### Urgent Chip

```css
background: #ffe5e5;
color: #ba1a1a;
```

Label examples:

- Urgent
- Not Urgent

### New Chip

```css
background: #e8f1ff;
color: #1f477b;
```

Label:

- New

---

## 14. Safety Actions

Trust and safety must be visible but not distracting.

### Report Post

Every listing card must include:

```text
Report Post
```

Style:

```css
color: #ba1a1a;
font-size: 13px;
background: transparent;
```

### More Menu

The three-dot menu may include:

- Report Post
- Not Interested
- Block User

---

## 15. Advertisement Component

Adverts should appear under the filter sidebar, not inside the main listings flow.

### Sponsored Card

Recommended size:

```text
300px wide
300px to 350px tall
```

### Sponsored Card Content

- Advertisement label
- Image
- Headline
- Short description
- CTA button

Example:

```text
Advertisement

Get More Visibility for Your Swap Post

Upgrade to Premium and reach more professionals looking to swap.

Learn More
```

### Sponsored Card Style

```css
background: #eaf8ef;
border: 1px solid #becabc;
border-radius: 16px;
padding: 16px;
```

---

## 16. Pagination

Use pagination on listing-heavy pages.

### Pagination Style

Current page:

```css
background: #005f2e;
color: #ffffff;
```

Other pages:

```css
background: #ffffff;
color: #1a1c1e;
border: 1px solid #e2e8f0;
```

Radius:

```css
border-radius: 8px;
```

---

## 17. Search and Sorting

At the top of the listing area include:

- Page title
- Number of results found
- Sort dropdown
- List view toggle
- Grid view toggle

Example:

```text
Swap Listings
Found 256 swap requests

Sort by: Most Recent
```

---

## 18. Marketplace Alert Banner

Place above listing cards.

Example:

```text
Get better matches!
Create a swap post to get matched with professionals looking to swap with you.

[Create Swap Post]
```

Style:

```css
background: linear-gradient(90deg, #eaf8ef, #ffffff);
border: 1px solid #78db92;
border-radius: 12px;
```

---

## 19. Footer

Footer should use deep navy styling.

```css
background: #001b3c;
color: #ffffff;
```

Footer columns:

- Platform
- Account
- Information
- Resources
- Download Our App

---

## 20. Page Specific Notes

### Homepage

The homepage should prioritize:

1. Clear headline
2. Create Swap Post CTA
3. Browse Swaps CTA
4. Search bar
5. How it works
6. Featured listings
7. Zambia map
8. Statistics
9. Testimonials
10. Swap alerts
11. Footer

### Listings Page

The listings page should prioritize:

1. Filtering
2. Match score
3. Verified users
4. Report post option
5. Save listing
6. Advertisement sidebar
7. Pagination

### Profile Page

The profile page should prioritize:

1. Swap information
2. Verification status
3. Match compatibility
4. Work history
5. Reviews
6. Public profile controls

### Create Swap Post Page

Professional information should be auto-filled from the user profile.

Supporting documents should not be uploaded during post creation. Documents belong in the Verification Centre or Profile Documents section.

### Resources Centre

The Resources Centre should display free professional tools, guides, templates, forms, and lesson plans grouped by profession.

Categories:

- Health Workers
- Teachers
- Government
- Banking
- ICT
- Engineering
- NGO
- Career Development
- Templates and Forms

---

## 21. WordPress Implementation Notes

### Recommended Free MVP Stack

- Theme: Blocksy Free
- Page Builder: Gutenberg
- Forms: Fluent Forms Free
- User Profiles: Ultimate Member Free
- Messaging: Better Messages Free
- Search Filters: Filter Everything Free
- Membership: Paid Memberships Pro Free
- Resources Library: WordPress Posts and Categories

### First Paid Upgrade

If only one paid plugin can be purchased first, buy:

```text
JetEngine
```

Reason:

JetEngine enables custom swap listings, dynamic profiles, advanced directories, custom fields, and marketplace-style layouts.

Second paid upgrade:

```text
JetSmartFilters
```

Reason:

It improves search and filtering for province, district, profession, employer type, housing, and urgency.

---

## 22. Final Standard

StaffExchangeHub must look like a trustworthy professional exchange system, not a casual classified ads site.

Every page must make the user feel:

- This platform is safe
- This platform is professional
- This platform can help me find a real workplace swap
- This platform protects my identity until I choose to connect
- This platform is built for serious professionals
