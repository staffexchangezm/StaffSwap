---
name: Professional Exchange System
colors:
  surface: '#f9f9fc'
  surface-dim: '#dadadc'
  surface-bright: '#f9f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f6'
  surface-container: '#eeeef0'
  surface-container-high: '#e8e8ea'
  surface-container-highest: '#e2e2e5'
  on-surface: '#1a1c1e'
  on-surface-variant: '#3f493f'
  inverse-surface: '#2f3133'
  inverse-on-surface: '#f0f0f3'
  outline: '#6f7a6f'
  outline-variant: '#becabc'
  surface-tint: '#006d36'
  primary: '#005f2e'
  on-primary: '#ffffff'
  primary-container: '#007a3d'
  on-primary-container: '#a1ffb7'
  inverse-primary: '#78db92'
  secondary: '#3a5f94'
  on-secondary: '#ffffff'
  secondary-container: '#9fc2fe'
  on-secondary-container: '#294f83'
  tertiary: '#49554c'
  on-tertiary: '#ffffff'
  tertiary-container: '#616d63'
  on-tertiary-container: '#e1eee2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#94f8ad'
  primary-fixed-dim: '#78db92'
  on-primary-fixed: '#00210c'
  on-primary-fixed-variant: '#005227'
  secondary-fixed: '#d5e3ff'
  secondary-fixed-dim: '#a7c8ff'
  on-secondary-fixed: '#001b3c'
  on-secondary-fixed-variant: '#1f477b'
  tertiary-fixed: '#d9e6da'
  tertiary-fixed-dim: '#bdcabe'
  on-tertiary-fixed: '#131e17'
  on-tertiary-fixed-variant: '#3e4a41'
  background: '#f9f9fc'
  on-background: '#1a1c1e'
  surface-variant: '#e2e2e5'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  headline-sm:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.5'
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.3'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 32px
  xl: 48px
  container-max: 1200px
  gutter: 24px
---

## Brand & Style

The brand personality is rooted in institutional trust, career advancement, and professional reliability. It caters to a demographic of skilled workers (healthcare, education, finance) seeking workplace mobility. 

The design style is **Corporate / Modern** with a focus on structured data and clarity. It utilizes a high-density information architecture balanced by generous white space and a systematic grid. The aesthetic avoids unnecessary decoration, instead using subtle tonal layers and precise iconography to establish a sense of authority and security.

- **Trust:** Established through deep, conservative colors and "Verified" iconography.
- **Efficiency:** Achieved through clear categorization and actionable data visualizations.
- **Professionalism:** Reinforced by balanced typography and a "safe" UI environment.

## Colors

The palette is anchored by a deep **Forest Green** (Primary) representing growth and "go" signals, and a **Midnight Navy** (Secondary) providing professional weight and stability. 

- **Primary Green:** Used for primary actions (buttons), success states, and key highlights.
- **Secondary Navy:** Used for navigation backgrounds, footers, and high-level headings.
- **Functional Accents:** Light greens are used for success backgrounds (Verified badges), while soft greys and blues handle structural borders and background shifts.
- **Neutral Scale:** A clean range of greys for body text, secondary labels, and inactive states to ensure high legibility against the off-white background.

## Typography

This design system uses a dual-font strategy. **Manrope** is used for headlines and display elements to provide a modern, balanced, and approachable character. **Inter** is the workhorse for body text and functional labels, chosen for its exceptional legibility in data-dense environments.

- **Headlines:** Set in Manrope with tighter tracking for large sizes to maintain a cohesive visual block.
- **Body:** Inter is used for all paragraph text, ensuring clarity in long-form descriptions and profile details.
- **Information Hierarchy:** Distinctive font weights (Semi-bold/Bold) are used to differentiate labels from user data within form fields and profile cards.

## Layout & Spacing

The layout follows a **Fixed-Width Grid** for desktop (1200px max) and a fluid response for smaller devices. It utilizes a 12-column grid with a 24px gutter to maintain rigorous alignment of data cards and form fields.

- **Vertical Rhythm:** A base-4 spacing system ensures consistent padding and margins. 
- **Information Density:** Content-heavy pages (like Swap Listings) utilize "Tight" spacing (16px gaps), while marketing and landing pages use "Spacious" units (48px+) to allow the content to breathe.
- **Sidebar:** Dashboards use a fixed 260px left-hand navigation sidebar, providing quick access to account-level tools.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and crisp outlines rather than aggressive shadows. 

- **Surface 0:** The global background color (light grey-blue).
- **Surface 1:** Primary content cards (White) with a 1px soft border (#E2E8F0).
- **Depth:** Occasional soft, diffused shadows (0px 4px 12px rgba(0,0,0,0.05)) are used only for high-priority floating elements or to indicate interactivity on hover.
- **Backdrop Blurs:** Used sparingly on navigation bars to maintain context during scroll.

## Shapes

The shape language is **Rounded**, using 8px (0.5rem) as the standard radius. This softens the "corporate" feel, making the platform feel accessible without losing its professional edge.

- **Standard (8px):** Buttons, Input Fields, and secondary cards.
- **Large (16px):** Primary container cards and dashboard modules.
- **Circular:** Used exclusively for profile avatars and numerical "badges" (e.g., notification counts).

## Components

### Buttons
- **Primary:** Solid Forest Green with white text. High emphasis.
- **Secondary:** White background with Green or Navy border and text. Low-to-medium emphasis.
- **Ghost:** No background or border, used for utility actions (e.g., "Report Post").

### Cards
- **Profile/Listing Cards:** Use a white surface with a subtle 1px border. They contain a header section for name/title and a structured grid for job details.
- **Summary Cards:** Small, focused blocks with icons for "Quick Stats" or "Key Skills," using light background tints to group information.

### Input Fields
- **Text Inputs:** White background, 1px grey border, 8px corner radius. Labels sit above the field.
- **Status Chips:** Small, rounded pills with high-contrast text on light backgrounds (e.g., "Urgent" in red-tint, "Government Hospital" in blue-tint).

### Feedback Elements
- **Compatibility Score:** A circular progress ring (Green) to provide instant visual quantification of a "Match."
- **Verification Badges:** Small green checkmark icons paired with specific labels to validate user trust.